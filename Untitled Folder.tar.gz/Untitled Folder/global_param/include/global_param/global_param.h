//
// Created by wlh on 17-7-24.
//

#ifndef PROJECT_GLOBAL_PARAM_H
#define PROJECT_GLOBAL_PARAM_H

const double ODOMETRY_FACTOR = 0.0210386;


#endif //PROJECT_GLOBAL_PARAM_H
