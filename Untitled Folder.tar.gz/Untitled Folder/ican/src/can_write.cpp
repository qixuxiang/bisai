#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include <strstream>
#include <string>
#include <fstream>


#include <canlib.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

#include "ican/canframe.h"


using namespace std;

int i = 0;
int willExit = 0;
canHandle h;
int ret = -1;
int k = 0;
int channel=0;
int bitrate = BAUD_250K;

void sighand (int sig)
{
  switch (sig) {
  case SIGINT:
    willExit = 1;
    break;
  }
}



void ctlMsgCallback(ican::canframe can_msg)
{
	short data[4]={0,0,0,0};
	int id;
	int len;

	data[0] = (short)can_msg.data[0];
	data[1] = (short)can_msg.data[1];
	data[2] = (short)can_msg.data[2];
	data[3] = (short)can_msg.data[3];
	id = can_msg.id;
	len = can_msg.len;
//	
//    /* Send the messages */
//	ret = canWriteWait(h, id, &data , len*2, 0/*|canMSG_EXT*/, -1);      
//	if (ret != canOK || willExit) 
//		printf("error!\n");


//	speed_pwm = boss_order.data[0];
//	brake_pos = boss_order.data[1];	
//	order.id = 0x16C;
//	order.len = 4;
//	order.data[0] = (speed_pwm>>8)&0xFF;
//	order.data[1] = (speed_pwm)&0xFF;
//	order.data[2] = (brake_pos>>8)&0xFF;
//	order.data[3] = (brake_pos)&0xFF;
//	pub.publish(order);

//	int speed_pwm=1700;
//	int brake_pos=100;

//	data[0] = (unsigned char)(speed_pwm>>8)&0xFF;
//	data[1] = (unsigned char)(speed_pwm)&0xFF;	
//	data[2] = (unsigned char)(brake_pos>>8)&0xFF;
//	data[3] = (unsigned char)(brake_pos)&0xFF;
//	
//	id = 0x16C;
//	len = 4;

//	
//	int SteerAngle = (int)90*10;	
//	//发送转角信息
//	id = 0x201;
//	len = 2;
//	data[0] = (unsigned char)(900>>8)&0xFF;
//	data[1] = (unsigned char)900&0xFF;


	cout<<"id: "<<id<<endl;
	cout<<"len: "<<len<<endl;
	cout<<"data: "<<data[0]<<" "<<data[1]<<" "<<data[2]<<" "<<data[3]<<endl;
	
    /* Send the messages */
	ret = canWriteWait(h, id, &data , len*2, 0/*|canMSG_EXT*/, -1);      
	if (ret != canOK || willExit) 
		printf("error!\n");
}


 
int main (int argc, char *argv[])
{
  
//	errno = 0;
//	if (argc != 2 || (channel = atoi(argv[1]), errno) != 0) 
//	{
//		printf("usage %s channel\n", argv[0]);
//		exit(1);
//	} 
//	else 
//	{
//		printf("Sending messages on channel %d\n", channel);
//	}

	printf("Sending messages on channel %d\n", channel);

	/* Use sighand as our signal handler */
	signal(SIGINT, sighand);

	/* Allow signals to interrupt syscalls(in canReadBlock) */
	siginterrupt(SIGINT, 1);

	/* Open channel, set parameters and go on bus */

	h = canOpenChannel(channel, canOPEN_EXCLUSIVE | 0*canOPEN_REQUIRE_EXTENDED);
	if (h < 0) 
	{
		printf("canOpenChannel %d failed\n", channel);
		return -1;
	}
	canSetBusParams(h, bitrate, 4, 3, 1, 1, 0);
	canSetBusOutputControl(h, canDRIVER_NORMAL);  // Work-around for Leaf bug
	canBusOn(h);
  
	ros::init(argc, argv, "write");
	ros::NodeHandle nh;
	ros::Subscriber sub;
	sub = nh.subscribe("can_write", 10, ctlMsgCallback);
	ros::spin();
   
//	if (canWriteSync(h, 1000) != canOK) 
//	{
//		printf("Sync failed!\n");
//	}
//	canBusOff(h);
//	canClose(h);

  	return 0;
}
