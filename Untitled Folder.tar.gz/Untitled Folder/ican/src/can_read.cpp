#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include <strstream>
#include <string>
#include <fstream>


#include <canlib.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include "ican/canframe.h"

using namespace std;

int i = 0;
unsigned char willExit = 0;
int last;
time_t last_time = 0;

void checkChannels(void);


void sighand (int sig)
{
  switch (sig) {
  case SIGINT:
    willExit = 1;
    alarm(0);
    break;
  }
}

 
int main (int argc, char *argv[])
{
	checkChannels();
	//int argc, char *argv[];
	//argv[1] = ""channel0;
	canHandle h;
	int ret = -1;
	long id; 
	unsigned char msg[8];
	unsigned int dlc;
	unsigned int flag;
	unsigned long t;
	int channel = 0;
	int bitrate = BAUD_250K;
	int j;
	ican::canframe frame;
	//ofstream out("raw_msg2.txt");

	errno = 0;

	printf("Reading messages on channel %d\n", channel);
	

	/* Use sighand as our signal handler */
	signal(SIGALRM, sighand);
	signal(SIGINT, sighand);
	alarm(1);

	/* Allow signals to interrupt syscalls(in canReadBlock) */
	siginterrupt(SIGINT, 1);

	/* Open channels, parameters and go on bus */
	h = canOpenChannel(channel, canOPEN_EXCLUSIVE | canOPEN_REQUIRE_EXTENDED);
	if (h < 0) 
	{
		printf("canOpenChannel %d failed\n", channel);
		return -1;
	}

	canSetBusParams(h, bitrate, 4, 3, 1, 1, 0);
	canSetBusOutputControl(h, canDRIVER_NORMAL);
	canBusOn(h);

	ros::init(argc, argv, "read");
	ros::NodeHandle n;
	//ros::Publisher chatter_pub = n.advertise<std_msgs::String>("can_chat", 10);
	ros::Publisher frame_pub = n.advertise<ican::canframe>("can_frame", 1000);

	i = 0;

while (!willExit) {
     
    do { 
      ret = canReadWait(h, &id, &msg, &dlc, &flag, &t, -1);
      switch (ret) {
      case 0:
      {
      		std_msgs::String can_mag;
			std::stringstream ss;
      
			printf("(%d) id:%ld dlc:%d data: ", i, id, dlc);
			frame.id = id;
			frame.len = dlc;
			if (dlc > 8) 
			{
			  dlc = 8;
			}
			for (j = 0; j < dlc; j++)
			{
			  printf("%2.2x ", msg[j]);
			  
			  int tm = msg[j];
			  frame.data[j] = tm;
			  //out<<std::hex<<tm<<"\t";
//			  //cout<<tm;
//			  ss<<tm;
//	
//			  if(msg[j]<10)
//			  	ss << std::hex << "0" <<tm<<" ";
//			  else
//			  	ss << std::hex <<tm<<" ";
			}
			//out<<endl;
			//cout<<endl;
			frame_pub.publish(frame);
			
			//can_mag.data = ss.str();
			//ROS_INFO("%s", can_mag.data.c_str());
			//cout<<can_mag.data;
			//chatter_pub.publish(can_mag);
		
			//printf(" flags:0x%x time:%ld\n", flag, t);
			i++;
			if (last_time == 0) {
			  last_time = time(0);
			} else if (time(0) > last_time) {
			  last_time = time(0);
			  if (i != last) {
				//printf("rx : %d total: %d\n", i - last, i);
			  }
			  last = i;
			}		
      }
      break;
        
      case canERR_NOMSG:
        break;
      default:
        perror("canReadBlock error");
        break;
      }
    } while (ret == canOK);
    willExit = 1;
  }
  //out.close(); 
  canClose(h);
   
  sighand(SIGALRM);
  printf("Ready\n");

	return 0;
}

void checkChannels(void)
{
  int chanCount = 0;
  int stat, i;
  char name[256];
  unsigned int ean[2], fw[2], serial[2];
    
  stat = canGetNumberOfChannels(&chanCount);
  if (stat < 0) {
    printf("Error in canGetNumberOfChannels\n");
    exit(1);
  }
  if (chanCount < 0 || chanCount > 64) {
      printf("ChannelCount = %d but I don't believe it.\n", chanCount);
      exit(1);
  }
  else {
    if (chanCount == 1)
      printf("Found %d channel.\n", chanCount);
    else
      printf("Found %d channels.\n", chanCount);
  }

  for (i = 0; i < chanCount; i++) {
    stat = canGetChannelData(i, canCHANNELDATA_DEVDESCR_ASCII,
                             &name, sizeof(name));
    if (stat < 0) {
      printf("Error in canGetChannelData - DEVDESCR_ASCII\n");
      exit(1);
    }

    if (strcmp(name, "Kvaser Unknown") == 0) {
      stat = canGetChannelData(i, canCHANNELDATA_CHANNEL_NAME,
                               &name, sizeof(name));
      if (stat < 0) {
        printf("Error in canGetChannelData - CHANNEL_NAME\n");
        exit(1);
      }
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_UPC_NO,
                             &ean, sizeof(ean));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_UPC_NO\n");
      exit(1);
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_SERIAL_NO,
                             &serial, sizeof(serial));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_SERIAL_NO\n");
      exit(1);
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_FIRMWARE_REV,
                             &fw, sizeof(fw));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_FIRMWARE_REV\n");
      exit(1);
    }

    printf("channel %d = %s, %x-%05x-%05x-%x, (%d)%d, %d.%d.%d.%d\n",
           i, name,
           (ean[1] >> 12), ((ean[1] & 0xfff) << 8) | ((ean[0] >> 24) & 0xff),
           (ean[0] >> 4) & 0xfffff, (ean[0] & 0x0f),
           serial[1], serial[0],
           fw[1] >> 16, fw[1] & 0xffff, fw[0] >> 16, fw[0] & 0xffff);
  } 
}






