#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include <strstream>
#include <string>
#include <fstream>
#include <pthread.h>


#include <canlib.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include "ican/canframe.h"

using namespace std;


unsigned char willExit = 0;
int last;
time_t last_time = 0;

canHandle h;
int ret = -1;

long id; 
unsigned char msg[8];
unsigned int dlc;
unsigned int flag;
unsigned long t;
int channel = 0;
int bitrate = BAUD_250K;
int i=0;
int j=0;
int g_cnt=0;

char data[4]={0,0,0,0};
int len;
int write_flag = 0;
int read_flag = 0;
ican::canframe frame;

ros::Publisher frame_pub;
ros::Subscriber sub;



void checkChannels(void);
int initCanDev(void);

void sighand (int sig)
{
  switch (sig) {
  case SIGINT:
    willExit = 1;
    alarm(0);
    break;
  }
}

//--------------------接收线程------------------------
void *rcvThread(void *arg)
{
  while (ros::ok()) 
  {     
	//ROS_INFO("rcvThread: receive thread running");
	ret = canRead(h, &id, &msg, &dlc, &flag, &t);
	
	switch (ret) 
	{
		case 0:
		{	  
			//printf("(%d) id:%ld dlc:%d data: \n", i, id, dlc);
			frame.id = id;
			frame.len = dlc;
			if (dlc > 8) 
			{
			  dlc = 8;
			}
			for (j = 0; j < dlc; j++)
			{
			  //printf("%2.2x ", msg[j]);
			  
			  int tm = msg[j];
			  frame.data[j] = tm;
			}

			frame_pub.publish(frame);

			i++;
//			if (last_time == 0) {
//			  last_time = time(0);
//			} else if (time(0) > last_time) {
//			  last_time = time(0);
//			  if (i != last) {
//				//printf("rx : %d total: %d\n", i - last, i);
//			  }
//			  last = i;
//		    }		
	  }
	  break;
		
	  case canERR_NOMSG:
		break;
	  default:
	   // perror("canReadBlock error");
		break;
	}
     
  }
} //rcvThread

//--------------------发送线程------------------------
void ctlMsgCallback(ican::canframe can_msg)
{
	write_flag = 1;
	data[0] = (char)can_msg.data[0];
	data[1] = (char)can_msg.data[1];
	data[2] = (char)can_msg.data[2];
	data[3] = (char)can_msg.data[3];
	
	id = can_msg.id;
	len = can_msg.len;
	cout<<"id: "<<id<<endl;
	cout<<"len: "<<len<<endl;
	//cout<<"data: "<<data[0]<<" "<<data[1]<<" "<<data[2]<<" "<<data[3]<<endl;
	
	if(write_flag == 1)
	{
		/* Send the messages */
		int write_ret = canWriteWait(h, id, &data , len, canMSG_STD/*|canMSG_EXT*/, -1);
		if(write_ret==0)
			ROS_INFO("send message successfully!\n%d",write_ret);
		if(write_ret<0)
			ROS_INFO("send message failed!\n");

		canResetBus(h);
		write_flag = 0;
	}		
}



 
int main (int argc, char *argv[])
{
	checkChannels();

	initCanDev();
	
	
	ros::init(argc, argv, "read_write");
	ros::NodeHandle n;
	
	frame_pub = n.advertise<ican::canframe>("can_frame", 1000);
	sub = n.subscribe("can_write", 1, ctlMsgCallback);

	//Create receive thread
	pthread_t rcvThrID;   //receive thread ID
	int err;
	err = pthread_create(&rcvThrID, NULL, rcvThread, NULL);
	if (err != 0) 
	{
		ROS_ERROR("unable to create receive thread");
		return -1;
	}
	ros::spin();

	canClose(h);

	sighand(SIGALRM);
	printf("Ready\n");

	return 0;
}



int initCanDev(void)
{
	errno = 0;

	printf("Reading messages on channel %d\n", channel);
	
	/* Use sighand as our signal handler */
	signal(SIGALRM, sighand);
	signal(SIGINT, sighand);
	alarm(1);

	/* Allow signals to interrupt syscalls(in canReadBlock) */
	siginterrupt(SIGINT, 1);

	/* Open channels, parameters and go on bus */
	h = canOpenChannel(channel, canOPEN_EXCLUSIVE | canOPEN_REQUIRE_EXTENDED);
	if (h < 0) 
	{
		printf("canOpenChannel %d failed\n", channel);
		return -1;
	}

	canSetBusParams(h, bitrate, 4, 3, 1, 1, 0);
	canSetBusOutputControl(h, canDRIVER_NORMAL);
	canBusOn(h);
	return 0;
}

void checkChannels(void)
{
  int chanCount = 0;
  int stat, i;
  char name[256];
  unsigned int ean[2], fw[2], serial[2];
    
  stat = canGetNumberOfChannels(&chanCount);
  if (stat < 0) {
    printf("Error in canGetNumberOfChannels\n");
    exit(1);
  }
  if (chanCount < 0 || chanCount > 64) {
      printf("ChannelCount = %d but I don't believe it.\n", chanCount);
      exit(1);
  }
  else {
    if (chanCount == 1)
      printf("Found %d channel.\n", chanCount);
    else
      printf("Found %d channels.\n", chanCount);
  }

  for (i = 0; i < chanCount; i++) {
    stat = canGetChannelData(i, canCHANNELDATA_DEVDESCR_ASCII,
                             &name, sizeof(name));
    if (stat < 0) {
      printf("Error in canGetChannelData - DEVDESCR_ASCII\n");
      exit(1);
    }

    if (strcmp(name, "Kvaser Unknown") == 0) {
      stat = canGetChannelData(i, canCHANNELDATA_CHANNEL_NAME,
                               &name, sizeof(name));
      if (stat < 0) {
        printf("Error in canGetChannelData - CHANNEL_NAME\n");
        exit(1);
      }
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_UPC_NO,
                             &ean, sizeof(ean));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_UPC_NO\n");
      exit(1);
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_SERIAL_NO,
                             &serial, sizeof(serial));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_SERIAL_NO\n");
      exit(1);
    }

    stat = canGetChannelData(i, canCHANNELDATA_CARD_FIRMWARE_REV,
                             &fw, sizeof(fw));
    if (stat < 0) {
      printf("Error in canGetChannelData - CARD_FIRMWARE_REV\n");
      exit(1);
    }

    printf("channel %d = %s, %x-%05x-%05x-%x, (%d)%d, %d.%d.%d.%d\n",
           i, name,
           (ean[1] >> 12), ((ean[1] & 0xfff) << 8) | ((ean[0] >> 24) & 0xff),
           (ean[0] >> 4) & 0xfffff, (ean[0] & 0x0f),
           serial[1], serial[0],
           fw[1] >> 16, fw[1] & 0xffff, fw[0] >> 16, fw[0] & 0xffff);
  } 
}






