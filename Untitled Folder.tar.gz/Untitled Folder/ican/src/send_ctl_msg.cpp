#include "ros/ros.h"
#include "std_msgs/String.h"
#include <string>
#include <iostream>
#include <fstream> 
#include <strstream>
#include "ican/canframe.h"
#include "ican/ctl_msg.h"

using namespace std;

	

int main(int argc, char **argv)
{
	ros::init(argc, argv, "send_ctl_msg");
	ros::NodeHandle n;
    
  ros::Publisher pub = n.advertise<ican::ctl_msg>("control_msg", 10);

  ros::Rate loop_rate(10);

  ican::ctl_msg ctl_data;
  ctl_data.SteerAngle = 30;
  ctl_data.Speed = 10;
  ctl_data.ImBOSS = 1;
  ctl_data.BossOrder[0] = 0;
  ctl_data.BossOrder[1] = 0;
  ctl_data.EMG = 0;
  ctl_data.OtherMsg = 1;
  
  while (ros::ok())
  {

    pub.publish(ctl_data);
    ROS_INFO("pub");
    
    //ros::spinOnce();
    loop_rate.sleep();
    }

    return 0;
}




