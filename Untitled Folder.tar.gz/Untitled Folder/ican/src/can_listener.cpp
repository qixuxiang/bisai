#include "ros/ros.h"
#include "std_msgs/String.h"
#include <string>
#include <iostream>
#include "ican/canframe.h"

using namespace std;


int id,len,data[4];
ican::canframe frame;


int get_data(string str, int* data);
int get_id(string str);
int get_len(string str);
string&  replace_all(string& str,const string& old_value,const string& new_value);


void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  //ROS_INFO("I heard: [%s]", msg->data.c_str());
  std::string s = msg->data.c_str();
  std::cout<<s<<"\n";
  //cout<<s.size()<<endl;
  
  string s_id = s.substr(5,3); 
  id = get_id(s_id);
//  cout<<id<<endl;
  
  
  string s_len = s.substr(9,1); 
  len = get_len(s_len);
//  cout<<len<<endl;
  
  string s_data = s.substr(13,11); 
//  cout<<s_data<<endl;
  string s_data_sub = replace_all(s_data," ","");
  //int data[4];
  get_data(s_data_sub, data);
  
//  for(int i=0;i<len;i++)
//  	cout<<data[i]<<" ";
//  cout<<endl;
  
  frame.id = id;
  frame.len = len;
  for(int i=0;i<len;i++)
  	frame.data[i] = data[i];
  ros::NodeHandle _n;
  ros::Publisher pub = _n.advertise<ican::canframe>("can_frame", 10);
   //ros::Publisher pub = n.advertise<ican::canframe>("can_frame", 10);
   pub.publish(frame);
   
}
	

int main(int argc, char **argv)
{

  ros::init(argc, argv, "listener");
  
 
  ros::NodeHandle n;

  ros::Publisher pub = n.advertise<ican::canframe>("can_frame", 10);
  ros::Rate loop_rate(10);

  
  while(ros::ok())
  {
  	  //ros::Subscriber sub = n.subscribe("can_chat", 10, chatterCallback);
	ros::Subscriber sub = n.subscribe("can_chat", 10, chatterCallback);
	ros::spin();
	//pub.publish(frame);
	//ros::spinOnce();
	//loop_rate.sleep();
  }

  return 0;
}

int get_data(string str, int* data)  
{  
	char high,low;
	int h,l;
	int temp;
	int ii=0;
	for(int i=0;i<str.size();i+=2)
	{
		high = str[i];
		low = str[i+1];
		
		if(high>='0' && high<='9')  
            h = high-'0';  
        else if(high>='A' && high<='F')  
            h = high - 'A' + 10;  
        else if(high>='a' && high<='f')  
            h = high - 'a' + 10;  
        else  
            return -1;  
          
        if(low>='0' && low<='9')  
            l = low-'0';  
        else if(low>='A' && low<='F')  
            l = low - 'A' + 10;  
        else if(low>='a' && low<='f')  
            l = low - 'a' + 10;  
        else  
            return -1;  
        
		temp = h<<4|l;
		data[ii] = temp;
//		cout<<std::hex<<temp<<" ";
//		
//		cout<<std::dec<<data[ii]<<" ";
		ii++;
	}

    return 0;  
}

int get_id(string str)
{
	char high,mid,low;
	int h,m,l;
	int id;
	
	high = str[0];
	mid = str[1];
	low = str[2];
	
	if(high>='0' && high<='9')  
        h = high-'0';  
    else if(high>='A' && high<='F')  
        h = high - 'A' + 10;  
    else if(high>='a' && high<='f')  
        h = high - 'a' + 10;  
    else  
        return -1;  
    
    if(mid>='0' && mid<='9')  
        m = mid-'0';  
    else if(mid>='A' && mid<='F')  
        m = mid - 'A' + 10;  
    else if(mid>='a' && mid<='f')  
        m = mid - 'a' + 10;  
    else  
        return -1;
      
    if(low>='0' && low<='9')  
        l = low-'0';  
    else if(low>='A' && low<='F')  
        l = low - 'A' + 10;  
    else if(low>='a' && low<='f')  
        l = low - 'a' + 10;  
    else  
        return -1;
        
    id = (h<<8)|(m<<4)|l; 
    return id;
       
}

int get_len(string str)
{
	char l;
	int len;
	
	l = str[0];
	if(l>='0' && l<='9')  
        l = l-'0';  
    else if(l>='A' && l<='F')  
        l = l - 'A' + 10;  
    else if(l>='a' && l<='f')  
        l = l - 'a' + 10;  
    else  
        return -1; 
        
    len = l;
    return len;
    
}


string&  replace_all(string&   str,const   string&   old_value,const   string&   new_value)   
{   
    while(true)   {   
        string::size_type   pos(0);   
        if(   (pos=str.find(old_value))!=string::npos   )   
            str.replace(pos,old_value.length(),new_value);   
        else   break;   
    }   
    return   str;   
}  

