#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Int8MultiArray.h"
#include "std_msgs/Int32MultiArray.h"
#include "std_msgs/Float64MultiArray.h"
#include <string>
#include <iostream>
#include <fstream> 
#include <strstream>
#include "ican/canframe.h"
#include "ican/ctl_msg.h"

using namespace std;


class CanFrameSendAndEncoder
{
public:
    
CanFrameSendAndEncoder()
{
    pub = nh.advertise<ican::canframe>("can_write", 10);
    sub_iamboss = nh.subscribe("iamboss", 10, &CanFrameSendAndEncoder::iambossCallback,this);
    sub_bossorder = nh.subscribe("boss_order",10, &CanFrameSendAndEncoder::bossOrderCallback,this);
    sub_set_steer = nh.subscribe("set_steer",10, &CanFrameSendAndEncoder::setSteerCallback,this);
    
    ros::Timer timer1;
    timer1 = nh.createTimer(ros::Duration(0.1), &CanFrameSendAndEncoder::testEncoder,this);
	test_cnt = 0;
    ros::spin();
}

void testEncoder(const ros::TimerEvent&)
{
	test_cnt++;
	
	order.data[0] = 0;
	order.data[1] = 0;
	order.data[2] = 0;
	order.data[3] = 0;
	
	if(test_cnt==1)
	{
		speed_pwm = 1700;
		brake_pos = 100;
		
		order.id = 0x16C;
		order.len = 4;
		order.data[0] = (speed_pwm>>8)&0xFF;
		order.data[1] = (speed_pwm)&0xFF;
		order.data[2] = (brake_pos>>8)&0xFF;
		order.data[3] = (brake_pos)&0xFF;
		pub.publish(order);
	}
	if(test_cnt==2)
	{
		SteerAngle = -3000;
		//发送转角信息
		order.id = 0x201;
		order.len = 2;
		order.data[0] = (SteerAngle>>8)&0xFF;
		order.data[1] = SteerAngle&0xFF;
		pub.publish(order);
		
		test_cnt = 0;
	}
}

void iambossCallback(std_msgs::Int8 iamboss)
{
	bossOrNot = iamboss.data;
}

void bossOrderCallback(std_msgs::Int32MultiArray boss_order)
{
	order.data[0] = 0;
	order.data[1] = 0;
	order.data[2] = 0;
	order.data[3] = 0;
		
	speed_pwm = boss_order.data[0];
	brake_pos = boss_order.data[1];
	
	order.id = 0x16C;
	order.len = 4;
	order.data[0] = (speed_pwm>>8)&0xFF;
	order.data[1] = (speed_pwm)&0xFF;
	order.data[2] = (brake_pos>>8)&0xFF;
	order.data[3] = (brake_pos)&0xFF;
	pub.publish(order);
}

void setSteerCallback(std_msgs::Float64 set_steer)
{
	order.data[0] = 0;
	order.data[1] = 0;
	order.data[2] = 0;
	order.data[3] = 0;

	SteerAngle = (int)set_steer.data*10;
	
	//发送转角信息
	order.id = 0x201;
	order.len = 2;
	order.data[0] = (SteerAngle>>8)&0xFF;
	order.data[1] = SteerAngle&0xFF;
	pub.publish(order);
	
}

//void chatterCallback(ican::ctl_msg ctl_data)
//{
//    cout<<"success publish"<<endl;

//    SteerAngle = ctl_data.SteerAngle*10;
//    Speed = ctl_data.Speed*100;
//    bossOrNot = ctl_data.ImBOSS;
//    //BossOrder = ctl_data.BossOrder;
//    speed_pwm = ctl_data.BossOrder[0];
//    brake_pos = ctl_data.BossOrder[1];   
//    emg = ctl_data.EMG;
//    OtherMsg = ctl_data.OtherMsg;

//    
//        //发送转角信息
//	order.id = 0x201;
//	order.len = 2;
//	order.data[0] = (SteerAngle>>8)&0xFF;
//	order.data[1] = SteerAngle&0xFF;
//	//if(m_bossOrNot!=1)
//	{
//		pub.publish(order);
//	}
//	//发送速度信息
//	order.id = 0x202;
//	order.len = 2;
//	order.data[0] = (Speed>>8)&0xFF;
//	order.data[1] = Speed&0xFF;
//	
//	if(bossOrNot!=1)
//	{
//		pub.publish(order);
//	}
//	//发送灯光控制
//	order.id = 0x203;
//	order.len = 1;
//	order.data[0] = 0;

//	if(bossOrNot!=1)
//	{
//		pub.publish(order);
//	}
//	//发送紧停状态
//	order.id = 0x204;
//	order.len = 1;
//	order.data[0] = emg;
//	
//	if(bossOrNot!=1)
//	{
//		pub.publish(order);
//	}
//	if(bossOrNot==1)
//	{
//		order.id = 0x16C;
//		order.len = 4;
//		order.data[0] = (speed_pwm>>8)&0xFF;
//		order.data[1] = (speed_pwm)&0xFF;
//		order.data[2] = (brake_pos>>8)&0xFF;
//		order.data[3] = (brake_pos)&0xFF;
//		pub.publish(order);
//	}   
//}
    
    
private:
    
    ros::NodeHandle nh;
    ros::Subscriber sub_iamboss;
    ros::Subscriber sub_bossorder;
    ros::Subscriber sub_set_steer;
    ros::Publisher pub;
    
    ican::canframe order;
        
    int id;
    int len;
    int data[4];
    int a,b;
    int SteerAngle;
    int Speed;
    int bossOrNot;
    int BossOrder;
    int speed_pwm;
    int brake_pos;
    int emg;
    int OtherMsg;
    
    int test_cnt;
};


	

int main(int argc, char **argv)
{
    ros::init(argc, argv, "encoder");
    CanFrameSendAndEncoder EncoderObject;

    return 0;
}




