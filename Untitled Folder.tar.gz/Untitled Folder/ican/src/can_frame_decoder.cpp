#include "ros/ros.h"
#include "std_msgs/String.h"
#include <string>
#include <iostream>
#include <fstream> 
#include <strstream>
#include "ican/canframe.h"
#include <std_msgs/Int16MultiArray.h>

using namespace std;

string get_sys_time(void);

class CanFrameRecvAndDecoder
{
public:
    
CanFrameRecvAndDecoder()
{
    ros::Rate loop_rate(10);  
    sub = n.subscribe("can_frame", 1000, &CanFrameRecvAndDecoder::chatterCallback,this);
    pub_pulse = n.advertise<std_msgs::Int16MultiArray>("pulse",10);
    ros::spin();
}

void chatterCallback(ican::canframe can_msg)
{
    
    for(int i=0;i<len;i++)
    	data[i] = can_msg.data[i];
    id = can_msg.id;
    len = can_msg.len;
    std_msgs::Int16MultiArray pulse;
    out_inf.open("CanMessage10251447.txt",ios::out|ios::app);    
     
    switch(id)
    {
	 case 0x181://转角
	    a=data[0]<<8;
	    b=a+data[1];
	    steerAngle = b*1.0/10;
	    cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"steerAngle: "<<steerAngle<<endl;
	        
	    out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"steerAngle: "<<std::dec<<steerAngle<<endl;	        
    	break;
    
    	case 0x182://脉冲
		pulses = data[0];
		pulses2 = data[1];
        	pulse.data.push_back(pulses);
        	pulse.data.push_back(pulses2);
        	pub_pulse.publish(pulse);

		cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"pulse1: "<<pulses<<"\t"
	        <<"pulse2: "<<pulses2<<endl;
	        
	        out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"pulse1: "<<pulses<<"\t"
	        <<"pulse2: "<<pulses2<<endl;
	break;
		
	case 0x183://里程(cm)
		mileage = ((can_msg.data[0])<<24) + ((can_msg.data[1])<<16) + ((can_msg.data[2])<<8) + (can_msg.data[3]);
		cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"mileage: "<<mileage<<endl;
	        
	        out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"mileage: "<<mileage<<endl;
	break;
		
	case 0x184://刹车油门位置
		brakePosition = ((can_msg.data[0])<<8)+(can_msg.data[1]);
		throttlePosition = ((can_msg.data[2])<<8)+(can_msg.data[3]);
		cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"brakePosition: "<<brakePosition<<"\t"
	        <<"throttlePosition: "<<throttlePosition<<endl;
	        
	        out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"brakePosition: "<<brakePosition<<"\t"
	        <<"throttlePosition: "<<throttlePosition<<endl;
	break;
		
	case 0x185://按键
		keys = can_msg.data[0];
		cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"keys: "<<keys<<endl;
	        
	        out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"keys: "<<keys<<endl;
	break;
		
	case 0x186://遥控
                remoteKeys = ((can_msg.data[0])<<8)+can_msg.data[1];
                cout<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"remoteKeys: "<<remoteKeys<<endl;
	        
	        out_inf<<"frame_id: "<<std::hex<<id<<"\t"    
	        <<"data_len: "<<len<<"\t"
	        <<"remoteKeys: "<<remoteKeys<<endl;		
	break;
	
	default:
	break;
    }
    
    out_inf.close();
    
}
    
    
private:
    
    ros::NodeHandle n;
    ros::Subscriber sub;
    ros::Publisher pub_pulse;
    
    ofstream out_inf;
    
        
    int id;
    int len;
    int data[4];
    int a,b;
    float steerAngle;
    int pulses,pulses2;
    int speed;
    int mileage;
    int brakePosition,throttlePosition;
    int keys,remoteKeys;

};


	

int main(int argc, char **argv)
{
    ros::init(argc, argv, "decoder");
    CanFrameRecvAndDecoder DecoderObject;
    

//    ros::NodeHandle n;
//    ros::Subscriber sub = n.subscribe("can_frame", 10, chatterCallback);
//    ros::Rate loop_rate(10);


//    while(ros::ok())
//    {
//      sub = n.subscribe("can_frame", 10, chatterCallback);
//      ros::spinOnce();
//      loop_rate.sleep();
//    }

    return 0;
}

string get_sys_time(void)
{
	struct tm *p;
	time_t timep;
	std::string timestamp;
	std::strstream temp;


	time(&timep);
	p = localtime(&timep);
	temp << p->tm_year + 1900 << setw(2) << setfill('0') << p->tm_mon
		<< setw(2) << setfill('0') << p->tm_mday
		<< setw(2) << setfill('0') << p->tm_hour
		<< setw(2) << setfill('0') << p->tm_min
		<< setw(2) << setfill('0') << p->tm_sec;
	temp >> timestamp;
	return timestamp;
}



