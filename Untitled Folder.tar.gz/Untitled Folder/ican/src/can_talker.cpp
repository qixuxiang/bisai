#include "ros/ros.h"
#include "std_msgs/String.h"
#include "ican/canframe.h"

#include <sstream>
#include <iostream>
using namespace std;

int main(int argc, char **argv)
{

  ros::init(argc, argv, "talker");


  ros::NodeHandle n;


  ros::Publisher can_pub = n.advertise<std_msgs::String>("can_chat", 10);

  ros::Rate loop_rate(10);

  while (ros::ok())
  {

    std_msgs::String msg; 
    std::stringstream ss,s2,s3,s4,s5,s6,s7,s8;
    
    ss <<"00000181"<<" "
    	<<"2"<<" "
    	<<"0"<<" "
    	<<"00"<<" "
    	<<"d9"<<endl;
    msg.data = ss.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    
    s2 <<"00000182"<<" "
    	<<"2"<<" "
    	<<"0"<<" "
    	<<"00"<<" "
    	<<"00"<<endl;
    msg.data = s2.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    
    s3 <<"00000183"<<" "
    	<<"4"<<" "
    	<<"0"<<" "
    	<<"00"<<" "
    	<<"01"<<" "
    	<<"08"<<" "
    	<<"03"<<endl;
    msg.data = s3.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    s4 <<"00000184"<<" "
    	<<"4"<<" "
    	<<"0"<<" "
    	<<"00"<<" "
    	<<"01"<<" "
    	<<"02"<<" "
    	<<"03"<<endl;
    msg.data = s4.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    s5 <<"00000185"<<" "
    	<<"1"<<" "
    	<<"0"<<" "	
    	<<"01"<<endl;
    msg.data = s5.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    s6 <<"00000186"<<" "
    	<<"2"<<" "
    	<<"0"<<" "
    	<<"00"<<" "
    	<<"81"<<endl;
    msg.data = s6.str();
    ROS_INFO("%s", msg.data.c_str());
    can_pub.publish(msg);
    
    
    //ros::spinOnce();
    loop_rate.sleep();
  }


  return 0;
}
