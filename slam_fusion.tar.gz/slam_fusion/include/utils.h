#ifndef __UTILS_H__
#define __UTILS_H__
#include <cmath>
using namespace std;


bool isZero(double num);
void constrainDegree(double &x);

#endif